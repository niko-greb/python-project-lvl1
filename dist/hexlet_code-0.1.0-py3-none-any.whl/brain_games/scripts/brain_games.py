#!/usr/bin/env python

"""Входи в игрую"""

from brain_games import cli


def main():
    """Вход в программу. Функция вызова функционала."""
    cli.welcome_user()


if __name__ == '__main__':
    main()
