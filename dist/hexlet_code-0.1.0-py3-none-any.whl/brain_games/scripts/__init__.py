"""Script examples."""
