"""Module examples."""
