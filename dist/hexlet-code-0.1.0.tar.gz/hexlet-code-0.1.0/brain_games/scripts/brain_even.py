#!/usr/bin/env python3

"""Enter to even-game."""

from brain_games import even


def main():
    even.even_check()


if __name__ == '__main__':
    main()
